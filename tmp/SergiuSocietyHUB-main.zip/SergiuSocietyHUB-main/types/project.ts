export type Category = "all" | "resto" | "ai" | "mkt" | "energy" | "ops" | "biz" | "life" | "security";

export interface Project {
  id: string;
  category: Category;
  emoji: string;
  name: string;
  description: string;
  targetAudience: string;
  innovationReason: string;
  link: string;
  status: "live" | "demo" | "under-construction";
  videoUrl?: string;
}

export interface CategoryInfo {
  id: Category;
  label: string;
  emoji: string;
  color: string;
  description?: string;
}
